SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE 
PROCEDURE	[dbo].[MU_DropCreateTables]
	@Action	TINYINT				, 
	@TableList NVARCHAR(MAX)	
	
/*Actions are as followed:
0 - Drop Meta Data
1 - Create Meta Data*/


AS
SET NOCOUNT	ON
IF			@Action = 0
BEGIN
	DECLARE		@TempTableD TABLE
			(
				rownum INT, 
				tableName NVARCHAR (200)
			)

	INSERT 
	INTO		@TempTableD
	SELECT		ROW_NUMBER() OVER(ORDER BY items),items
	FROM		Split(@TableList,',')

	DECLARE @TableName NVARCHAR(200)
	DECLARE @Script NVARCHAR (MAX)
	DECLARE @RowID INT

	SELECT	@RowID=MIN(rownum)
	FROM	@TempTableD		

	BEGIN TRY	
		WHILE	@RowID IS NOT NULL
		BEGIN
			SELECT	@TableName = tablename
			FROM	@TempTableD
			WHERE	rownum=@RowID
			
			EXEC	MU_ModifyTable 0, @TableName, @Script OUTPUT
			
			IF		LEN(@Script)>0
			EXEC	(@Script)
			PRINT	'Table '
				+	@TableName
				+	'''s MetaData was Dropped'
			
			SET		@Script = NULL
			SET		@TableName = NULL

			SELECT	@RowID = MIN(rownum)
			FROM	@TempTableD
			WHERE	rownum>@RowID
		END
	END TRY
	BEGIN CATCH
--		SELECT ERROR_MESSAGE()
		RAISERROR('Drop Failed',11,1);
	END CATCH
END

ELSE IF			@Action = 1
BEGIN 
	DECLARE		@TempTableC TABLE
				(
					rownum INT, 
					tableName NVARCHAR (200)
				)

	INSERT 
	INTO		@TempTableC
	SELECT		ROW_NUMBER() OVER(ORDER BY ordinalNum Desc),TableName
	FROM		dbo.DropCreateScripts
	WHERE		TableName IN (SELECT Items FROM Split(@TableList,','))	
	

	SELECT	@RowID=MIN(rownum)
	FROM	@TempTableC		

	WHILE	@RowID IS NOT NULL
	BEGIN
		SELECT	@TableName = tablename
		FROM	@TempTableC
		WHERE	rownum=@RowID
		
		
		SELECT	@Script = CreateCommad
		FROM	dbo.DropCreateScripts
		WHERE	TableName = @TableName
		
		BEGIN TRANSACTION;
			BEGIN TRY
				EXEC		(@Script);
				EXEC		MU_ModifyTable 1, @TableName
				PRINT		'Table '
					+		@TableName
					+		'''s Metadata was Created'
			END TRY
			BEGIN CATCH
--				SELECT ERROR_MESSAGE()  
				RAISERROR	('Creation Failed',11,1);
				IF			@@TRANCOUNT>0
					ROLLBACK TRANSACTION;
			END CATCH
			IF @@TRANCOUNT>0
				COMMIT TRANSACTION
	
		SET		@Script = NULL
		SET		@TableName = NULL

		SELECT	@RowID = MIN(rownum)
		FROM	@TempTableC
		WHERE	rownum>@RowID
	END
END



GO