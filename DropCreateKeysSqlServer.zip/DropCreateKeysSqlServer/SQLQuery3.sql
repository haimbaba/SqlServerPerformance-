SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[MU_GenerateScripts]
	@action [tinyint],
	@TableList [varchar](max) = '',
	@Text [nvarchar](max) OUTPUT
WITH EXECUTE AS CALLER
AS
SET NOCOUNT	ON
DECLARE		@object_id INT
DECLARE		@SQL VARCHAR(MAX)=''
DECLARE		@CMD VARCHAR (MAX)=''

SELECT		@object_id=object_id FROM sys.tables where name=@TableList
IF			@action=0
BEGIN
	
	SELECT		@SQL=	''
	SELECT		@SQL=	COALESCE(@SQL,'')
					+	'ALTER INDEX ['+[name]+ '] on  ' + '['+ OBJECT_SCHEMA_NAME(object_id) +'].['+OBJECT_NAME([OBJECT_ID]) + '] REBUILD;
'
	FROM		sys.indexes TI
	WHERE		[object_id] = @object_id
	AND			type_desc <> 'CLUSTERED'
	------------------------------------------------------------------------------
	select @SQL=isnull(@SQL,'')
	SELECT		@CMD =	@CMD 
					+	@SQL +'
'

----------------------------------
-- added By Shlomo   2010 09 01
-- for repair next problem :when ew have relation by more of one columns we got
-- script for create for each column separate but with equal name
-- next change for repair this .
SET		@SQL=	''
-- 1.Declare variables

	DECLARE @fk_name sysname,
			@constraint_column_name sysname,
			@referenced_object sysname,
			@ref_owner sysname,
			@referenced_column_name sysname,
			@is_disabled int,
			@is_not_for_replication int,
			@delete_referential_action int,
			@update_referential_action int,
			@with_check varchar(15)
	------------------------------------------------------
	DECLARE @fk_name1 sysname,
			@table_name1 sysname,
			@table_name  sysname,
			@owner1 sysname,
			@owner sysname,
			@constraint_column_name1 sysname,
			@referenced_object1 sysname,
			@ref_owner1 sysname,
			@referenced_column_name1 sysname,
			@is_disabled1 int,
			@is_not_for_replication1 int,
			@delete_referential_action1 int,
			@update_referential_action1 int,
			@with_check1 varchar(15)
	----------------------------------------------------
	DECLARE @col_list1 varchar(max),
			@col_list2 varchar(max)

	-- foreign key constraints
	--DROP TABLE tempdb.[dbo].[fk_constr]

	-- foreign key constraints - columns description
	--DROP TABLE tempdb.[dbo].[fk_constr_cols]

	-- *************************************************
	-- foreign key constraints info
	-- *************************************************
	declare   @fk_constr TABLE
	(
	[table_name]				[sysname],
	[owner]						[sysname],
	[fk_constr]					[sysname],
	[referenced_table]			[sysname],
	[referenced_table_owner]	[sysname],
	[update_referential_action] [tinyint],
	[delete_referential_action] [tinyint],
	[is_not_for_replication]	[bit],
	[is_disabled]				[bit],
	[const_id]					[int]
	)
	declare  @fk_constr_cols TABLE 
	(
	[foreign_key_name]			[sysname],
	[table_name]				[sysname],
	[owner]						[sysname],
	[constraint_column_name]	[nvarchar](128),
	[referenced_object]			[sysname],
	[ref_owner]					[sysname],
	[referenced_column_name]	[nvarchar](128),
	[is_disabled]				[bit],
	[is_not_for_replication]	[bit],
	[delete_referential_action] [tinyint],
	[update_referential_action] [tinyint],
	[constraint_column_id]		[int],
	[with_check]				[varchar](12)
	)
-- 2 populate temp tables

-- '-- GET FOREIGN KEY CONSTRAINTS INFO'

INSERT  INTO @fk_constr
	SELECT  OBJECT_NAME(f.parent_object_id) Parent_Table,
	OBJECT_SCHEMA_NAME(f.parent_object_id) Parent_Schema,
	f.[name] FK_Const,
	OBJECT_NAME(f.referenced_object_id) Child_Table,
	OBJECT_SCHEMA_NAME(f.referenced_object_id) Child_Schema,
	f.[update_referential_action],
	f.[delete_referential_action],
	f.[is_not_for_replication],
	f.[is_disabled],
	f.[object_id]
	FROM    sys.foreign_keys f
	join sys.objects ot on ot.[object_id] = f.parent_object_id
	join sys.schemas st on st.schema_id = ot.schema_id
	join sys.objects otr on otr.[object_id] = f.referenced_object_id
	join sys.schemas st1 on st1.schema_id = otr.schema_id
	
	WHERE f.parent_object_id=@object_id
	OR f.referenced_object_id=@object_id

-- '-- GET FOREIGN KEY CONSTRAINTS & COLUMNS INFO'

INSERT  INTO @fk_constr_cols
	SELECT  f.[name] AS foreign_key_name,
	OBJECT_NAME(f.parent_object_id) AS table_name,
	OBJECT_SCHEMA_NAME(f.parent_object_id) AS owner,
	COL_NAME(fc.parent_object_id, fc.parent_column_id) AS constraint_column_name,
	OBJECT_NAME(f.referenced_object_id) AS referenced_object,
	OBJECT_SCHEMA_NAME(f.referenced_object_id) AS ref_owner,
	COL_NAME(fc.referenced_object_id, fc.referenced_column_id) AS referenced_column_name,
	f.is_disabled,
	f.[is_not_for_replication],
	f.delete_referential_action--_desc
	,
	f.update_referential_action--_desc
	,
	fc.constraint_column_id,
	[with_check] = case f.is_not_trusted
	when 1 then 'WITH NOCHECK'
	else ''
	end
	FROM    sys.foreign_keys AS f
	JOIN sys.foreign_key_columns AS fc ON f.[object_id] = fc.constraint_object_id
	--join sys.objects ot on ot.[object_id] = f.parent_object_id
	--join sys.schemas st on st.schema_id = ot.schema_id
	--join sys.objects otr on otr.[object_id] = f.referenced_object_id
	--join sys.schemas st1 on st1.schema_id = otr.schema_id
	--JOIN @fk_constr tfc on tfc.[const_id] = fc.constraint_object_id
	
	WHERE f.parent_object_id=@object_id
	OR f.referenced_object_id=@object_id
	order by f.[name],fc.constraint_column_id
-- 3  '-- CREATE FK CONSTRAINTS'
DECLARE @COUNT INT
select  @COUNT=COUNT(1)
		from    @fk_constr_cols

DECLARE ms_fk_cursor2 CURSOR
		FOR select  foreign_key_name,
		table_name,
		owner,
		constraint_column_name,
		referenced_object,
		ref_owner,
		referenced_column_name,
		is_disabled,
		is_not_for_replication,
		delete_referential_action,
		update_referential_action,
		with_check
		from    @fk_constr_cols
		order by foreign_key_name,
		constraint_column_id

open ms_fk_cursor2

fetch next from ms_fk_cursor2 into @fk_name, @table_name, @owner,
@constraint_column_name, @referenced_object, @ref_owner,
@referenced_column_name, @is_disabled, @is_not_for_replication,
@delete_referential_action, @update_referential_action, @with_check

SELECT  @col_list1 = '[' + @constraint_column_name + ']',
@col_list2 = '[' + @referenced_column_name + ']'

WHILE @@fetch_status >= 0
BEGIN
		fetch next from ms_fk_cursor2 into @fk_name1, @table_name1, @owner1, @constraint_column_name1 
		, @referenced_object1, @ref_owner1, @referenced_column_name1, @is_disabled1
		, @is_not_for_replication1, @delete_referential_action1, @update_referential_action1, @with_check1

IF @@fetch_status < 0 BREAK

IF @fk_name != @fk_name1
	BEGIN
	--IF @fk_name <> @fk_name1
	--BEGIN
	-- new row, add constraint for prev row

		SELECT		@SQL=	COALESCE(@SQL,'') +
		'ALTER TABLE [' + @owner + '].[' + @table_name + '] ' 
		+	' WITH NOCHECK ADD CONSTRAINT [' + -- + @with_check +	 ' ADD CONSTRAINT [' + 
		@fk_name + '] FOREIGN KEY (' + @col_list1 + ') 
		REFERENCES [' + @ref_owner + '].[' + 
		@referenced_object + '] (' + @col_list2 + ')'
		+	' ;
	'  
		--SELECT (@SQL)
	
		SELECT @fk_name = @fk_name1, @table_name = @table_name1, @owner = @owner1
		, @constraint_column_name = @constraint_column_name1 
		, @referenced_object = @referenced_object1, @ref_owner = @ref_owner1
		, @referenced_column_name = @referenced_column_name1, @is_disabled = @is_disabled1
		, @is_not_for_replication = @is_not_for_replication1
		, @delete_referential_action = @delete_referential_action1
		, @update_referential_action = @update_referential_action1
		, @with_check = @with_check1

		SELECT @col_list1 = '[' + @constraint_column_name + ']'
		, @col_list2 = '[' + @referenced_column_name + ']'
	END
ELSE
	BEGIN 
		SELECT	 @col_list1 = @col_list1 + ',[' 
				+ @constraint_column_name1 + ']'
				,@col_list2 = @col_list2 + ',[' 
				+ @referenced_column_name1 + ']'
	END
END
SELECT		@SQL=	COALESCE(@SQL,'') +
'ALTER TABLE [' + @owner + '].[' + @table_name + '] ' 
+	' WITH NOCHECK ADD CONSTRAINT [' + -- + @with_check +	 ' ADD CONSTRAINT [' + 
@fk_name + '] FOREIGN KEY (' + @col_list1 + ') 
REFERENCES [' + @ref_owner + '].[' + 
@referenced_object + '] (' + @col_list2 + ')'
+	' ;
'  
-- close cursor
CLOSE ms_fk_cursor2
DEALLOCATE ms_fk_cursor2
--PRINT '-- CREATE FK CONSTRAINTS passed'
------------------------------------------------------------------------------
-- END shlomo added changed text
-------------------------------------------------------------------------------
select @SQL=isnull(@SQL,'')
--select @CMD,@SQL
	SELECT		@CMD =	@CMD 
					+	isnull(@SQL,'')
--select @CMD,@SQL
		
	SELECT		@SQL=	''
	SELECT		@SQL=	COALESCE(@SQL,'')
					+	'ALTER TABLE ['
					+	OBJECT_SCHEMA_NAME(parent_object_id)
					+	'].['
					+	OBJECT_NAME(parent_object_id)
					+	']  CHECK CONSTRAINT ['
					+	[Name]
					+	'];
'  
	FROM		sys.foreign_keys
	WHERE		parent_object_id = @object_id
	-------------------------------------------------------------------------------

		SELECT		@CMD =	@CMD 
					+	@SQL
					+	'UPDATE STATISTICS ['
					+OBJECT_SCHEMA_NAME(object_id )
					+'].'
					+	@TableList
					
	from sys.tables where [object_id] =@object_id
	 
	SET			@Text = @CMD
END



/*****************************************
**				Drop Script				**
*****************************************/

ELSE IF		@action=1
BEGIN
	SELECT		@CMD=	''

	SELECT		@SQL=	''
	SELECT		@SQL=	COALESCE(@SQL,'')
					+	'ALTER TABLE ['
					+	OBJECT_SCHEMA_NAME(parent_object_id)
					+	'].['
					+	OBJECT_NAME(parent_object_id)
					+	']  NOCHECK CONSTRAINT ['
					+	[Name]
					+	'];
'  
	FROM		sys.foreign_keys
	WHERE		parent_object_id = @object_id
	-------------------------------------------------------------------------------
	select @SQL=isnull(@SQL,'')
	SELECT		@CMD =	@CMD 
					+	@SQL
					+	'
'
	
	SELECT		@SQL=	''
	SELECT		@SQL=	COALESCE(@SQL,'')
					+	'ALTER TABLE ['
					+	OBJECT_SCHEMA_NAME(parent_object_id)
					+	'].['
					+	OBJECT_NAME(parent_object_id)
					+	'] DROP CONSTRAINT ['
					+	[Name]
					+	'];
'  
	FROM		sys.foreign_keys
	WHERE		referenced_object_id = @object_id
	OR			parent_object_id = @object_id
	-------------------------------------------------------------------------------
	select @SQL=isnull(@SQL,'')
	SELECT		@CMD =	@CMD 
					+	@SQL 
					+	'
'

	SELECT		@SQL=	''
	SELECT		@SQL=	COALESCE(@SQL,'')
					+	'ALTER INDEX ['
					+	[name]+ '] on  ['
					+	OBJECT_SCHEMA_NAME([OBJECT_ID])
					+	'].['
					+	OBJECT_NAME([OBJECT_ID])
					+	'] Disable;
'
	FROM		sys.indexes
	WHERE		[object_id] = @object_id
	AND			type_desc <> 'CLUSTERED'
	-------------------------------------------------------------------------------
	select @SQL=isnull(@SQL,'')
	SELECT		@CMD =	@CMD
					+	@SQL

	SET			@Text = @CMD

END
ELSE
BEGIN
	PRINT 'Unknown Action'
END



GO