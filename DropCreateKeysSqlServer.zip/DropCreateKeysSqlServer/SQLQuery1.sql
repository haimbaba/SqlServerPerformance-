SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[DropCreateScripts](
	[OrdinalNum] [int] NOT NULL,
	[TableName] [nvarchar](200) NOT NULL,
	[DropCommand] [nvarchar](max) NOT NULL,
	[CreateCommad] [nvarchar](max) NOT NULL
) ON [PRIMARY]

GO


