SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE 
PROCEDURE	[dbo].[MU_ModifyTable] 
	@Action	TINYINT							, 
	@Table NVARCHAR(200)					,
	@DropScript NVARCHAR (MAX)='' OUTPUT	,
	@CreateScript NVARCHAR (MAX)='' OUTPUT

	
/*Actions are as followed:
0 - Add To Table
1 - Remove From Table
2 - Check If Exists*/


AS
SET NOCOUNT	ON

if not exists(select null from sys.tables where name=@Table)
begin 
select 'Table'+@Table+' not exist. Check table name and/or schema name'
return
end


IF			@Action = 0
BEGIN
	IF EXISTS	(SELECT		TableName 
				FROM		dbo.DropCreateScripts
				WHERE		TableName =@Table)
		RAISERROR ('No,no,no... This Action  Already Done.Check table DropCreate', 11, 1)

	ELSE
	BEGIN
		EXEC MU_GenerateScripts 0, @Table, @CreateScript OUTPUT
		EXEC MU_GenerateScripts 1, @Table, @DropScript OUTPUT
		DECLARE @OrdinalNum INT = null
		SELECT	@OrdinalNum=ISNULL(MAX(OrdinalNum),0)+1 FROM dbo.DropCreateScripts
			

		INSERT INTO dbo.DropCreateScripts (OrdinalNum,TableName,CreateCommad,DropCommand)
		VALUES(@OrdinalNum,@Table,@CreateScript,@DropScript)
	END
END
ELSE IF		@Action = 1
BEGIN
	IF EXISTS	(SELECT		TableName 
				FROM		dbo.DropCreateScripts
				WHERE		TableName =@Table)
		DELETE 
		FROM	dbo.DropCreateScripts
		WHERE	TableName =@Table
	
	ELSE
		RAISERROR ('No Table Found',11,1)
END
ELSE IF		@Action = 2
BEGIN
	IF EXISTS	(SELECT		TableName  
				FROM		dbo.DropCreateScripts
				WHERE		TableName = @Table)
		SELECT	0
	ELSE
		SELECT	1
END




GO