 -- Use 0 for Drop
 exec dbo.MU_DropCreateTables 0,'ContactType'

 -- Drop Command and Create Command 
 select * from [dbo].[DropCreateScripts]

 -- Use 1 For Create
  exec dbo.MU_DropCreateTables 0,'ContactType'

  -- Check that table is empty
   select * from [dbo].[DropCreateScripts]
